## Shopify
Shopify theme structure and a minimal theme setup. For detailed templates and code examples have a look at the **Shopify Theme Lab** [Foundation Theme](https://github.com/uicrooks/shopify-foundation-theme), or the official [Shopify Dawn Theme](https://github.com/Shopify/dawn).

## Links
- [Shopify Theme Docs](https://shopify.dev/themes)
- [Shopify Cheat Sheet](https://www.shopify.com/partners/shopify-cheat-sheet)